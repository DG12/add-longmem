# 3.0.0
 - Stable release

# 0.2.0
 - Add UART-specific `0xCA` endpoint for Ruuvi Gateway.

# 0.1.0
 - Add iBeacon and Ruuvi RAWv1, RAWv2 (0x03, 0x05).