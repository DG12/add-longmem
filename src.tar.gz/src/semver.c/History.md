
v1.0.0 / 2017-10-01
===================

* Make implementation closer to the semver specification.
* Fixes #15.

